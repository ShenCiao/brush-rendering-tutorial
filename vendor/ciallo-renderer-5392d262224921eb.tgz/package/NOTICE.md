# Source attribution

The initial implementation was extracted from
[ShenCiao/brush-rendering-tutorial](https://github.com/ShenCiao/brush-rendering-tutorial),
commit `ab13de828b351076800a76b938680910ec41fc7a`:

- `src/rendering/format.ts`
- `src/rendering/WebGpuRenderer.ts`
- `src/rendering/GpuTimer.ts`
- `src/rendering/shaders.ts`
- `tests/polygon-coverage.spec.ts` (kept as a repository test, not a package export)

The source repository's README licenses the work under
[Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/).
Original work and rendering research are credited to Shen Ciao and the
contributors identified in that repository. This extraction retains that license
and attribution. Changes initially cover module packaging and tests; the rendering
algorithms and shader equations are preserved.

The shader implementation follows Ciallo's Gaussian Airbrush and polygon-fill
antialiasing. Ciallo's source repository separately documents its
[shader code terms](https://github.com/ShenCiao/Ciallo#shader-code-special-notice).
No artwork from the tutorial gallery is bundled in this package.
