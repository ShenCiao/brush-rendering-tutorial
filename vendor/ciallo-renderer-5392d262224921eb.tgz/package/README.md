# @ciallo/renderer (private)

WebGPU renderer for Ciallo `.glb2dim` files. No framework dependency.
Installed from a local `.tgz`, not npm.

## Usage

```js
import { RenderDocument, WebGpuRenderer } from "@ciallo/renderer";

const response = await fetch("/artwork.glb2dim");
if (!response.ok) throw new Error(`Download failed: ${response.status}`);
const document = new RenderDocument(await response.arrayBuffer()); // throws on bad files
const renderer = await WebGpuRenderer.create(canvas, document, console.error);

canvas.width = 1000;
canvas.height = 700;
const [left, top, right, bottom] = document.bounds;
renderer.render({
  x: (left + right) / 2,   // document point shown at the canvas center
  y: (top + bottom) / 2,
  scale: 0.9 * Math.min(canvas.width / (right - left), canvas.height / (bottom - top)),
});

// Call this later, when removing the viewer or before loading another file:
// renderer.dispose();
```

Things to know:

- Importing the package does nothing by itself, so it is safe in SSR. Call
  `create()` in the browser once the canvas exists (in React, inside an effect).
- WebGPU needs HTTPS or localhost and a supported GPU. There is no WebGL fallback.
  If `create()` throws, show a static image instead.
- `canvas.width/height` and `scale` are in real pixels, not CSS pixels. Multiply
  by `devicePixelRatio` yourself if you want sharp output.
- The renderer draws only when you call `render()`. Camera controls, resizing, and
  deciding when to redraw are up to you.

## API

- `new RenderDocument(arrayBuffer)`: parses and checks a file. Gives `artwork`,
  `bounds` (for fitting the camera), and `counts`.
- `WebGpuRenderer.create(canvas, document, onError)`: sets up the GPU. `onError`
  receives errors that happen later, such as losing the GPU.
- `render(camera, comparison?, onTiming?)`: draws one frame and returns stats.
  `onTiming` is called later with GPU time, if the device supports it.
- `setSampleCount(1 | 4)`: turns 4× MSAA on or off. Discards the baked bitmap
  when the sample count changes.
- `dispose()`: frees all GPU resources.
- `settled()`: resolves when the GPU has finished submitted work (handy in tests).

Optional bitmap comparison, used by the gallery to compare the live vector
image against a fixed-resolution raster:

- `attachComparison(canvas)`: prepares a second canvas.
- `bakeBitmap(longEdge)`: renders the whole document once to a bitmap whose
  longer side is `longEdge` pixels (64 to `maxBitmapLongEdge`).
- `render(camera, { context, filter, difference, gain, grid })`: also draws the
  bitmap on the second canvas with the same camera.
- `clearBitmap()`: frees the bitmap.

To only parse files: `import { RenderDocument } from "@ciallo/renderer/format"`.

The package is plain ESM with type declarations. Shaders are embedded as strings,
so no bundler plugin or loader is needed.

## Supported content

Format version 1, profile `ciallo-airbrush-2`, linear sRGB. One frame with
Airbrush strokes (including erasers), solid fills, groups with opacity and
Normal/Add/Multiply blending, and clipping. Not glTF, and it cannot open
`.ciallo` project files.

## Attribution

Extracted from `ShenCiao/brush-rendering-tutorial`. See `NOTICE.md` for source
and license.
